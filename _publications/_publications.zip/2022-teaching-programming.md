---
title: "Teaching Programming Skills in Methods Courses is an Opportunity, not a Burden"
collection: publications
permalink: /publication/2022-teaching-programming
date: 2022-01-01
venue: 'PS: Political Science & Politics'
paperurl: '/files/pdf/teaching/Teaching Programming.pdf'
link: 'https://doi.org/10.1017/S1049096521001153'
citation: 'Williams, Rob. 2022. &quot;Teaching Programming Skills in Methods Courses is an Opportunity, not a Burden.&quot; <i>PS: Political Science & Politics</i> 55(1): 221-224. doi:10.1017/S1049096521001153'
---