---
title: "Under the Roof of Rebels: Civilian Targeting After Territorial Takeover in Sierra Leone"
collection: publications
permalink: /publication/2020-civilian-targeting
date: 2020-06-08
venue: 'International Studies Quarterly'
paperurl: '/files/pdf/research/Under the Roof of Rebels.pdf'
link: 'https://doi.org/10.1093/isq/sqaa009'
code: 'https://doi.org/10.7910/DVN/BEKPWV'
citation: 'Oswald, Christian, Melanie Sauter, Sigrid Weber, and Rob Williams.<sup>*</sup> 2020. &quot;Under the Roof of Rebels: Civilian Targeting After Territorial Takeover in Sierra Leone.&quot; <i>International Studies Quarterly</i> 64(2): 295–305. doi:10.1093/isq/sqaa009'
---